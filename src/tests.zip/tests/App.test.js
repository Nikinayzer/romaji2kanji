import { render, screen } from '@testing-library/react';
import App from '../App';


test('test', () => {
  /*
  render(<App />);
  const linkElement = screen.getByText(/Romaji2kanji/i);
  expect(linkElement).toBeInTheDocument();
  */
});

